package com.firstproject.firstproject.food.foodstorage;

public enum StorageType {
    냉장,냉동
}
